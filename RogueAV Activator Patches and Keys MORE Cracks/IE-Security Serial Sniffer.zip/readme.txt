Copy the sniffer into the folder where IE-Security is installed
Kill all processes like taskkill /f /im iescan.exe then
Open the sniffer and click on click on Get the serial and follow the instructions to get the serial
related to the email you typed.